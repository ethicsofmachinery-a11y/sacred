SACRED SCRIPTURES WEBSITE

Open index.html in a browser.

Included:
- Genesis
- Profectus
- Apocalypsis
- Scripture-wide search
- Book navigation
- Clickable search results that jump to verses
- Mobile-friendly layout

To publish it online for free, upload the four site files to GitHub Pages.
